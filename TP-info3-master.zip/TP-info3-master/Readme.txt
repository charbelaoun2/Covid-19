

	$$$$$$$$\ $$$$$$$\        $$$$$$\            $$$$$$\            $$$$$$\  
	\__$$  __|$$  __$$\       \_$$  _|          $$  __$$\          $$ ___$$\ 
	   $$ |   $$ |  $$ |        $$ |  $$$$$$$\  $$ /  \__|$$$$$$\  \_/   $$ |
	   $$ |   $$$$$$$  |        $$ |  $$  __$$\ $$$$\    $$  __$$\   $$$$$ / 
	   $$ |   $$  ____/         $$ |  $$ |  $$ |$$  _|   $$ /  $$ |  \___$$\ 
	   $$ |   $$ |              $$ |  $$ |  $$ |$$ |     $$ |  $$ |$$\   $$ |
	   $$ |   $$ |            $$$$$$\ $$ |  $$ |$$ |     \$$$$$$  |\$$$$$$  |
	   \__|   \__|            \______|\__|  \__|\__|      \______/  \______/ 
                                                                         
                                                                         
                                                                         
	 $$$$$$\                      $$\       $$\         $$\   $$$$$$\        
	$$  __$$\                     \__|      $$ |      $$$$ | $$  __$$\       
	$$ /  \__| $$$$$$\ $$\    $$\ $$\  $$$$$$$ |      \_$$ | $$ /  $$ |      
	$$ |      $$  __$$\\$$\  $$  |$$ |$$  __$$ |$$$$$$\ $$ | \$$$$$$$ |      
	$$ |      $$ /  $$ |\$$\$$  / $$ |$$ /  $$ |\______|$$ |  \____$$ |      
	$$ |  $$\ $$ |  $$ | \$$$  /  $$ |$$ |  $$ |        $$ | $$\   $$ |      
	\$$$$$$  |\$$$$$$  |  \$  /   $$ |\$$$$$$$ |      $$$$$$\\$$$$$$  |      
	 \______/  \______/    \_/    \__| \_______|      \______|\______/       
                                                                         
                                                                         
                                                                        
____________

 CONTENTS
____________

 1. INSTALLATION
 2. SYSTEM REQUIREMENTS
 3. USER GUIDE
 4. CONTACT INFORMATION
__________________________________________________________________________

 1. INSTALLATION
_________________________

 pip install requests
 pip install beautifulsoup4
 pip install matplotlib
 pip install Pillow
 pip install hashlib

__________________________________________________________________________

 2. SYSTEM REQUIREMENTS
_______________________

 This App was tested only on windows

__________________________________________________________________________

 3. USER GUIDE 
_________________________

 Run main.py to launch the Application in user mode.
 Run main.py with optional arguments -u and -p to launch the Application in admin mode. ex how to use it in cmd: python main.py -u admin -p password123
 Watch the videos for more details.

__________________________________________________________________________

 4. CONTACT INFORMATION
_________________________

 Every effort has been made to make our product as compatible with current hardware as possible. However if you are experiencing problems you may contact us in one of the several ways
 listed below.


 E-mail:
  georges.farah2114@gmail.com
  charbel.aoun3@net.usj.edu.lb

 Web Address:
  https://gfarah.com
